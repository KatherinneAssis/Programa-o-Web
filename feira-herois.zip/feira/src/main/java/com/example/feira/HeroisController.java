package com.example.feira;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")
public class HeroisController {

    private List<Heroi> herois = new ArrayList<>(List.of(
        new Heroi("Saitama", "Careca super forte e resistente", 10_000_000),
        new Heroi("Fubuki", "Poderes psiquicos medianos", 7_000),
        new Heroi("Genos", "Cyborg com poderosas habilidades de fogo e tecnologia avançada", 100),
        new Heroi("Silver Fang", "Mestre de artes marciais extremamente poderoso e experiente", 12_000),
        new Heroi("Tatsumaki", "Usuária de poderes psíquicos extremamente poderosos", 9_500_000)
    ));

    @GetMapping
    public List<Heroi> getHerois(){
        return herois;
    }

    @GetMapping("/novo/{nome}/{descricao}/{forca}")
    public Heroi addHeroi(@PathVariable String nome, @PathVariable String descricao, @PathVariable Integer forca){
        Heroi heroi = new Heroi(nome, descricao, forca);
        herois.add(heroi);
        return heroi;
    }


    @GetMapping("/classe/{classe}")
    public List<Heroi> categoryHeroes(@PathVariable String classe){
        return herois.stream().filter(heroi -> heroi.getClasse().equals(classe)).toList();
    }
}

package com.example.feira;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/frutas")
public class FrutaController {

    private List<String> frutasList = new ArrayList<>(List.of("Maçã", "Banana", "Laranja", "Uva", "Morango", "Abacaxi", "Kiwi", "Melancia", "Melão", "Manga", "Pera", "Limão", "Tangerina", "Cereja", "Papaia"));

    @GetMapping
    public List<String> getFrutas(){
        return frutasList;
    }

    @GetMapping("/nova/{fruta}")
    public String insertFruta(@PathVariable String fruta){
        frutasList.add(fruta);
        return "Fruta %s foi cadastrada com sucesso!".formatted(fruta);
    }

    @GetMapping("/contagem")
    public Integer countFruta(){
        return frutasList.size();
    }

    @GetMapping("/consulta/{fruta}")
    public String checkFruta(@PathVariable String fruta){
        return frutasList.contains(fruta) ? "Fruta encontrada!" : "Fruta não encontrada";
    }
}

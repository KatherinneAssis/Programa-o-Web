package sptech.projetojpa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@Configuration
@SpringBootApplication
public class ProjetoJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoJpa2Application.class, args);
	}

}